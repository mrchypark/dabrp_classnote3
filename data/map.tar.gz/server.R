## run for shiny

options(encoding = 'UTF-8')
library(shiny)
library(leaflet)
library(RColorBrewer)
load("./tdata.RData")
#tdata<-tdata[,.(place_id,date,lat,lng,dateNum,chkin,cate)]
#tdata$cate<-as.factor(tdata$cate)
#levels(tdata$cate)<-letters[1:22]

tdata$dateNumc<-as.numeric(as.factor((tdata$dateNum)))
tdata<-tdata[tdata$dateNumc!=50,]

function(input, output, session) {
  
  # Reactive expression for the data subsetted to what the user selected
  filteredData <- reactive({
#    tdata[tdata$dateNum <= input$dateNum & tdata$dateNum > input$dateNum-15,]
    tdata[tdata$dateNumc == input$dateNum,]
  })
  
  # This reactive expression represents the palette function,
  # which changes as the user makes selections in UI.
#  colorpal <- reactive({
#    colorFactor(input$colors, tdata$cate)
#  })
  
  output$map <- renderLeaflet({
    # Use leaflet() here, and only include aspects of the map that
    # won't need to change dynamically (at least, not unless the
    # entire map is being torn down and recreated).
    l <- leaflet(tdata) %>% addTiles() %>%
     # addProviderTiles("Stamen.TonerLite") %>%
      setView(126.9,37.5 ,zoom = 11)
    
    esri <- grep("^Esri", providers, value = TRUE)
    
    for (provider in esri) {
      l <- l %>% addProviderTiles(provider, group = provider)
    }
    
    l %>%
      addLayersControl(baseGroups = names(esri),
                       options = layersControlOptions(collapsed = FALSE)) %>%
      addMiniMap(tiles = esri[[1]], toggleDisplay = TRUE,
                 position = "bottomleft") %>%
      htmlwidgets::onRender("
    function(el, x) {
      var myMap = this;
      myMap.on('baselayerchange',
        function (e) {
          myMap.minimap.changeLayer(L.tileLayer.provider(e.name));
        })
    }")
    
  })
  
  # Incremental changes to the map (in this case, replacing the
  # circles when a new color is chosen) should be performed in
  # an observer. Each independent set of things that can change
  # should be managed in its own observer.
  observe({
 #   pal <- colorpal()
    
    leafletProxy("map", data = filteredData()) %>%
      clearShapes() %>%
      addCircles(radius = ~sqrt(chkin) * input$size, weight = 1, color = "#4c80f1",
                 fillColor = "#4c80f1", fillOpacity = 0.1,
                 popup = ~paste(cate)
      )
  })
  
  # Use a separate observer to recreate the legend as needed.
#  observe({
#    proxy <- leafletProxy("map", data = tdata)
    
    # Remove any existing legend, and only if the legend is
    # enabled, create a new one.
#   proxy %>% clearControls()
#    if (input$legend) {
#      pal <- colorpal()
#      proxy %>% addLegend(position = "bottomright",
#                          pal = pal, values = ~cate
#      )
    }
#  })
#}
