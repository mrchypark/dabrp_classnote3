## run for shiny

options(encoding = 'UTF-8')

library(shiny)
library(leaflet)
library(RColorBrewer)

load("./tdata.RData")
#tdata<-tdata[,.(place_id,date,lat,lng,dateNum,chkin,cate)]
#tdata$cate<-as.factor(tdata$cate)
#levels(tdata$cate)<-letters[1:22]

tdata$dateNumc<-as.numeric(as.factor((tdata$dateNum)))
tdata<-tdata[tdata$dateNumc!=50,]

bootstrapPage(
  tags$style(type = "text/css", "html, body {width:100%;height:100%}"),
  tags$head(
    # Include our custom CSS
    includeCSS("styles.css"),
    includeScript("gomap.js")
  ),
  leafletOutput("map", width = "100%", height = "100%"),
  absolutePanel(id = "controls", class = "panel panel-default", fixed = TRUE,
                draggable = TRUE, top = 60, left = 60, right = "auto", bottom = "auto",
                width = 330, height = "auto",
                h2("가맹점 매출 시각화"),
                br(),
                p("모 기업의 기간에 따른 가맹점 모집 현황과 그 가맹점의 매출을 시각화한 자료 입니다. 본 박스 하단의 슬라이드가 각 시점을 의미하며, 오른쪽에 'Play' 버튼을 누르면 에니메이션처럼 자동으로 진행됩니다."),
                sliderInput("size","Amount circle size:", 10,100,value=15,step=10),
                sliderInput("dateNum", "Date :", min(tdata$dateNumc), max(tdata$dateNumc),
                            value = min(tdata$dateNumc),step=1,
                            animate = animationOptions(interval = 1000,loop = T, playButton = div(br(),p("Play")),
                                                       pauseButton = div(br(),p("Pause"))))               

                #selectInput("colors", "Color Scheme",
                 #           rownames(subset(brewer.pal.info, category %in% c("div")))
                #),
                #checkboxInput("legend", "Show legend", TRUE)
  )
)
