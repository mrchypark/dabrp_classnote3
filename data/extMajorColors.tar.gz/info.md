 최적화가 되지 않아 아직 많이 느립니다. 인내심을 가지고 기다리시면 처리 됩니다. png, jpg 등 이미지라면 동작하는 것을 확인했습니다만, 문제가 있으면 [여기](https://github.com/mrchypark/shiny_extract_major_colors_form_png/issues)에 남겨주세요. 코드는 [여기](https://github.com/mrchypark/shiny_extract_major_colors_form_png)에서 확인할 수 있습니다. [원본 코드](https://github.com/encaion/encaion/blob/Visualization/extract_major_colors_form_png.R)를 제공해주신 [김승욱](https://www.facebook.com/encaion)님 감사합니다.

예시 그림 url : https://gephi.org/images/screenshots/layout2.png
